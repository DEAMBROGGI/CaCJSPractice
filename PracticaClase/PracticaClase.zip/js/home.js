function displayHome(){
    return  ` 
    <div class="home_image"></div>
    <div class="home_buttons">
        <a href="./pages/characters.html">Characters</a>
        <a href="./pages/episodes.html">Episodes</a>
        <a href="./pages/locations.html">Locations</a>
    </div> `
}