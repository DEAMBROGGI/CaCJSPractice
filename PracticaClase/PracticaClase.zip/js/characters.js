function displayCharacters(){
    return "<h1>ESTOY EN CHARACTER</h1>"
}